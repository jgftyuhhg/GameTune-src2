package com.gametune.control.core

import com.gametune.control.root.RootShell

enum class PowerMode(val cmd: String, val label: String) {
    POWERSAVE("powersave", "省电"),
    BALANCE("balance", "均衡"),
    PERFORMANCE("performance", "性能"),
    FAST("fast", "极速"),
    PEDESTAL("pedestal", "狂暴")
}

object GameEngine {
    private const val CFG_PATH = "/data/powercfg.json"
    private const val STATE_PATH = "/sdcard/Android/yc/uperf/cur_powermode.txt"

    suspend fun isUperfInstalled(): Boolean = RootShell.readFile(CFG_PATH).isNotBlank()
    
    suspend fun setMode(mode: PowerMode): Boolean {
        val entry = RootShell.readFile(CFG_PATH).let { json ->
            Regex("\"entry\"\\s*:\\s*\"([^\"]+)\"").find(json)?.groupValues?.get(1) ?: "/data/powercfg.sh"
        }
        return if (entry.isNotEmpty()) RootShell.execOk("sh $entry ${mode.cmd}")
        else RootShell.execOk("echo '${mode.cmd}' > $STATE_PATH")
    }
    
    suspend fun currentMode(): PowerMode? = PowerMode.entries.firstOrNull { it.cmd == RootShell.readFile(STATE_PATH).trim() }
    
    suspend fun setRefreshRate(hz: Int): Boolean {
        val ok1 = RootShell.execOk("svc power set-refresh-rate $hz")
        val ok2 = RootShell.execOk("echo $hz > /sys/class/graphics/fb0/refresh_rate 2>/dev/null")
        return ok1 || ok2
    }
    
    suspend fun getCurrentRefreshRate(): Int {
        val r = RootShell.readFile("/sys/class/graphics/fb0/refresh_rate").toIntOrNull()
        return r ?: 60
    }
    
    suspend fun enableSchedulingTakeover(): Boolean {
        val cmds = listOf(
            "stop perfd; stop miuibooster; stop vendor.perfservice",
            "for d in /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq; do max=\$(cat \$(dirname \$d)/cpufreq/cpuinfo_max_freq); echo \$max > \$d 2>/dev/null; done",
            "echo '0' > /sys/class/kgsl/kgsl-3d0/min_pwrlevel 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_clk_on 2>/dev/null",
            "echo '1' > /sys/class/kgsl/kgsl-3d0/force_bus_on 2>/dev/null",
            "for d in /sys/class/devfreq/*gpu*; do [ -f \$d/min_freq ] && max=\$(cat \$d/max_freq 2>/dev/null) && [ -n \"\$max\" ] && echo \$max > \$d/min_freq 2>/dev/null; done"
        )
        return cmds.any { RootShell.execOk(it) }
    }
    
    suspend fun disableSchedulingTakeover(): Boolean {
        val cmds = listOf(
            "start perfd; start miuibooster; start vendor.perfservice"
        )
        return cmds.any { RootShell.execOk(it) }
    }
    
    suspend fun isTakeoverActive(): Boolean = RootShell.readFile("/sys/class/kgsl/kgsl-3d0/min_pwrlevel") == "0"
    
    suspend fun getCurrentFPS(): Int {
        val out = RootShell.exec("dumpsys surfaceflinger 2>/dev/null | head -20")
        val m = Regex("(\\d+)").find(out)
        return m?.value?.toIntOrNull() ?: 0
    }
}
