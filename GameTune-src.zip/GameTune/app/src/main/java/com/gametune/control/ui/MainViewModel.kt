package com.gametune.control.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gametune.control.core.PowerMode
import com.gametune.control.core.GameEngine
import com.gametune.control.root.RootShell
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _isRoot = MutableStateFlow(false)
    val isRoot: StateFlow<Boolean> = _isRoot.asStateFlow()
    private val _refreshOn = MutableStateFlow(false)
    val refreshOn: StateFlow<Boolean> = _refreshOn.asStateFlow()
    private val _schedOn = MutableStateFlow(false)
    val schedOn: StateFlow<Boolean> = _schedOn.asStateFlow()
    private val _currentMode = MutableStateFlow<PowerMode?>(null)
    val currentMode: StateFlow<PowerMode?> = _currentMode.asStateFlow()
    private val _currentHz = MutableStateFlow(60)
    val currentHz: StateFlow<Int> = _currentHz.asStateFlow()

    fun refresh() {
        viewModelScope.launch {
            _isRoot.value = RootShell.isRoot()
            _currentMode.value = GameEngine.currentMode()
            _schedOn.value = GameEngine.isTakeoverActive()
            _currentHz.value = GameEngine.getCurrentRefreshRate()
            _refreshOn.value = _currentHz.value >= 144
        }
    }
    fun setRefreshRate(on: Boolean) {
        viewModelScope.launch {
            val target = if (on) 144 else 60
            if (GameEngine.setRefreshRate(target)) _refreshOn.value = on
            delay(500); _currentHz.value = GameEngine.getCurrentRefreshRate()
        }
    }
    fun enableSched() { viewModelScope.launch { if (GameEngine.enableSchedulingTakeover()) _schedOn.value = true } }
    fun disableSched() { viewModelScope.launch { GameEngine.disableSchedulingTakeover(); _schedOn.value = false } }
    fun setMode(mode: PowerMode) { viewModelScope.launch { GameEngine.setMode(mode); delay(300); _currentMode.value = GameEngine.currentMode() } }
}
